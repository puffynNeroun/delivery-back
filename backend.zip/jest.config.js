module.exports = {
    testEnvironment: 'node',
};
