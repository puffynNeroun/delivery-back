const { supabase } = require('../config/db');

// Регистрация пользователя
const registerUser = async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({ message: 'Все поля обязательны' });
        }

        const normalizedEmail = email.toLowerCase();

        // Создаём пользователя в Supabase Auth
        const { data, error } = await supabase.auth.signUp({
            email: normalizedEmail,
            password
        });

        if (error || !data?.user) {
            console.error('Ошибка регистрации в Supabase:', error);
            return res.status(400).json({ message: 'Ошибка регистрации', error: error?.message });
        }

        console.log('✅ Пользователь зарегистрирован в Supabase:', data.user.id);

        // Проверяем, есть ли пользователь в таблице users
        let { data: existingUser, error: checkError } = await supabase
            .from('users')
            .select('id')
            .eq('id', data.user.id)
            .single();

        if (!existingUser) {
            // Если пользователя с таким ID нет в базе, добавляем его
            const { error: dbError } = await supabase
                .from('users')
                .insert([{ id: data.user.id, email: normalizedEmail, is_admin: false }]);

            if (dbError) {
                console.error('Ошибка сохранения пользователя в users:', dbError);
                return res.status(500).json({ message: 'Ошибка сохранения в БД', error: dbError.message });
            }

            console.log('✅ Пользователь успешно добавлен в users:', data.user.id);
        }

        res.status(201).json({
            message: 'Регистрация успешна',
            user: {
                id: data.user.id,
                email: data.user.email,
                isAdmin: false
            }
        });
    } catch (error) {
        console.error('Ошибка регистрации:', error);
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// Вход пользователя
const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });

        if (error || !data?.user) {
            return res.status(401).json({ message: 'Неверные email или пароль' });
        }

        const userId = data.user.id;
        const userEmail = data.user.email;

        // Проверяем, есть ли пользователь в таблице users по ID
        let { data: userInDb, error: checkError } = await supabase
            .from('users')
            .select('id, email, is_admin')
            .eq('id', userId) // <-- ИСПРАВЛЕНО! Ищем по id, а не по email
            .single();

        if (!userInDb) {
            console.log('❌ Пользователь не найден в таблице users, добавляем его:', userId);

            const { error: insertError } = await supabase
                .from('users')
                .insert([{ id: userId, email: userEmail, is_admin: false }]);

            if (insertError) {
                console.error('Ошибка при добавлении пользователя в users:', insertError);
                return res.status(500).json({ message: 'Ошибка при добавлении пользователя' });
            }

            ({ data: userInDb } = await supabase
                .from('users')
                .select('id, email, is_admin')
                .eq('id', userId)
                .single());
        }

        res.cookie('token', data.session.access_token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'Strict',
            maxAge: 60 * 60 * 1000 // 1 час
        });

        res.json({
            message: 'Вход успешен',
            user: {
                id: userInDb.id,
                email: userInDb.email,
                isAdmin: userInDb.is_admin
            }
        });
    } catch (error) {
        console.error('Ошибка авторизации:', error);
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// Выход пользователя
const logoutUser = async (req, res) => {
    try {
        await supabase.auth.signOut();
        res.clearCookie('token', { httpOnly: true, secure: true, sameSite: 'Strict' });
        res.cookie('token', '');
        res.json({ message: 'Выход выполнен' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

module.exports = { registerUser, loginUser, logoutUser };
