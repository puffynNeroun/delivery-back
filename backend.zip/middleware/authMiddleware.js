const { supabase } = require('../config/db');

// Middleware защиты роутов
const protect = async (req, res, next) => {
    const token = req.cookies.token;

    if (!token) {
        return res.status(401).json({ message: 'Нет токена, авторизация отклонена' });
    }

    try {
        const { data: userData, error } = await supabase.auth.getUser(token);

        if (error || !userData?.user) {
            return res.status(401).json({ message: 'Неверный или истекший токен' });
        }

        const userId = userData.user.id;
        const userEmail = userData.user.email;

        // Проверяем пользователя в таблице users по EMAIL, а не по ID
        let { data: user, error: userError } = await supabase
            .from('users')
            .select('id, email, is_admin')
            .eq('email', userEmail) // <--- ИСПРАВЛЕНО!
            .single();

        if (!user) {
            console.log('❌ Пользователь не найден в базе, добавляем его:', userId);

            const { error: insertError } = await supabase
                .from('users')
                .insert([{ id: userId, email: userEmail, is_admin: false }]);

            if (insertError) {
                console.error('Ошибка при добавлении пользователя в users:', insertError);
                return res.status(500).json({ message: 'Ошибка при добавлении пользователя' });
            }

            ({ data: user } = await supabase
                .from('users')
                .select('id, email, is_admin')
                .eq('email', userEmail) // <--- ИСПРАВЛЕНО!
                .single());
        }

        req.user = {
            id: user.id,
            email: user.email,
            isAdmin: user.is_admin
        };

        console.log("✅ Пользователь авторизован:", req.user);
        next();
    } catch (error) {
        console.error('Ошибка авторизации:', error);
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};


// Middleware проверки администратора
const admin = (req, res, next) => {
    if (!req.user?.isAdmin) {
        return res.status(403).json({ message: 'Доступ запрещен, требуется роль администратора' });
    }
    next();
};

module.exports = { protect, admin };
